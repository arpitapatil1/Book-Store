<?php

session_start();
include('db.php');
$status="";
if (isset($_POST['code']) && $_POST['code']!=""){
$code = $_POST['code'];
$result = mysqli_query($con,"SELECT * FROM `products` WHERE `code`='$code'");
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$code = $row['code'];
$price = $row['price'];
$image = $row['image'];

$cartArray = array(
  $code=>array(
  'name'=>$name,
  'code'=>$code,
  'price'=>$price,
  'quantity'=>1,
  'image'=>$image)
);

if(empty($_SESSION["shopping_cart"])) {
  $_SESSION["shopping_cart"] = $cartArray;
  $status = "<div class='box'>Product is added to your cart!</div>";
}else{
  $array_keys = array_keys($_SESSION["shopping_cart"]);
  if(in_array($code,$array_keys)) {
    $status = "<div class='box' style='color:red;'>
    Product is already added to your cart!</div>";  
  } else {
  $_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$cartArray);
  $status = "<div class='box'>Product is added to your cart!</div>";
  }

  }
}
?>
<html lang="en">
<head>
   <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <!-- Bootstrap CSS -->
  <!-- CSS only -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <title>Welcome to Books & Us Store</title>
  <link rel='stylesheet' href='css/style.css' type='text/css' media='all' />
  <link rel='stylesheet' href='css/stylenew.css' type='text/css' media='all' />

</head>

<body>

   <header>
    <div id="bottomHeader">
      <div class="container-fluid">
        <nav class="navbar navbar-dark navbar-expand-md" style="background-color:#004d80;">
          <!-- <a class="navbar-brand" href="">
            <img src="imgs/logo_text_white_small.png" width="250px" alt="">
          </a> -->
          <button data-toggle="collapse" data-target="#navbarToggler" type="button" class="navbar-toggler"><span class="navbar-toggler-icon"></span></button>
          <div class="collapse navbar-collapse" id="navbarToggler">
            <ul class="navbar-nav">
              <li class="nav-item active">
                <a class="nav-link" href="index.php">Home</a>
              </li>
              <li class="nav-item dropdown">
                
                  <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Categories
                  </a>
                  <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <li><a class="dropdown-item" href="#newarrival">Kids</a></li>
                    <li><a class="dropdown-item" href="#">Fiction</a></li>
                    <li><a class="dropdown-item" href="#">Arts</a></li>
                    <li><a class="dropdown-item" href="#">Sports</a></li>
                    <li><a class="dropdown-item" href="#">Tourisim</a></li>
                    <li><a class="dropdown-item" href="#">Motivation</a></li>
                  </ul>
               

              </li>
               <li class="nav-item">
                <a class="nav-link" href="aboutus.html">About Us</a>
              </li> 
              <li class="nav-item">
                <a class="nav-link" href="contactus.html">Contact Us</a>
              </li>
              
            </ul>
            
            
          </div>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item  login">
                <a class="nav-link" href="login.php">Login</a>
              </li>
              <li class="nav-item login">
                <a class="nav-link" href="signin.php">SignUp</a>
              </li>
              <li class="nav-item login">
                
            <div class='cart_div'>
                <a href='cart.php'><img src='cart-icon.png'/> Cart</a>
            </div>
              </li> 

          </ul>
        </nav>

      </div>
    </div>
  </header>


<div class="home">
  <div class="row mt-3">
    <div class="col-6">
            <h3 style="color:rgb(59, 199, 235);text-align: center;"><strong>Welcome to Books & Us Store</strong></h3>
    </div>
    <div class="col-6">
        <div class="input-group mb-3">
            <input type="text" class="form-control" placeholder="Search By Book Title" >
            <div class="input-group-append">
              <button class="btn btn-outline-secondary" type="submit">Search</button>
            </div>
          </div>
          
    </div>
    </div>
     <div class="container bg-light">
        <div class="m-auto" style="width:700px">
            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
          <div class="carousel-inner ">
            <div class="carousel-item active">
              <img src="product-images/b5.png" class="d-block w-100 " alt="slide1">
            </div>
            <div class="carousel-item">
              <img src="product-images/b2.jpg" class="d-block w-100 " alt="slide2">
            </div>
            <div class="carousel-item">
              <img src="product-images/b3.jpg" class="d-block w-100"alt="slide3">
            </div>
            <div class="carousel-item">
                <img src="product-images/b1.jpg" class="d-block w-100"alt="slide4">
              </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>
     </div>
 </div>  
<br>
<div style="width:700px; margin:auto;">
<?php
if(!empty($_SESSION["shopping_cart"])) {
$cart_count = count(array_keys($_SESSION["shopping_cart"]));
?>
 

<?php
}

$result = mysqli_query($con,"SELECT * FROM `products`");
$count=0;
while($row = mysqli_fetch_assoc($result)){
    if($count==2)
    {
      echo "<br>";
      $count=0;
    }
    echo "<div class='product_wrapper'>
        <form method='post' action=''>
        <input type='hidden' name='code' value=".$row['code']." />
        <div class='image'><img src='".$row['image']."' /></div>
        <div class='name'>".$row['name']."</div>
          <div class='price'>$".$row['price']."</div>
        <button type='submit' class='buy'>Buy Now</button>
        </form>
          </div>";
     $count=$count+1;
        }
mysqli_close($con);
?>
</div>
<div style="clear:both;"></div>

<div class="message_box" style="margin:10px 0px;">
<?php echo $status; ?>
</div>

</div>

<footer class="full-footer mt-5">
    <div class="container top-footer p-md-3 p-1">
      <div class="row">
        <div class="col-md-4 pl-4 pr-4">
          <img class="img-fluid" src="imgs/logo_text_white_small.png" alt="">
          <p>
            “Books are the quietest and most constant of friends; they are the most accessible and wisest of counselors, and the most patient of teachers.”
            – Charles W. Eliot
          </p>
          
        </div>

        <div class="col-md-4  pl-4 pr-4">
          <h3>Important Links</h3>
          <a href="#">Privacy Policy</a><br>
          <a href="#">Youtube Channel Link </a><br>
          <a href="#">Blog Articles </a><br>
          <a href="#">Social Media</a><br>
          <a style="color:silver;" class="p-1" href="#"><i class="fa fa-facebook-square" ></i></a>
          <a style="color: silver;" class="p-1" href="#"><i class="fa fa-envelope" ></i></a>
          <a style="color: silver;" class="p-1" href="#"><i class="fa fa-twitter-square"></i></a>
          <a style="color: silver;" class="p-1" href="#"><i class="fa fa-instagram"></i></a>
        </div>

     
      <div class="col-md-4  pl-4 pr-4">
          <h3>Contact Us</h3>
          <a href="#"><i class="fas fa-phone"></i> +(91) 9090909090  </a><br>
          <a href="mailto:abc@gmail.com  "><i class="fa fa-envelope" ></i> abc@gmail.com  </a><br>
          <div class="embed-responsive embed-responsive-16by9">
              <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d241316.64333236168!2d72.74110193617271!3d19.082522317332813!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c6306644edc1%3A0x5da4ed8f8d648c69!2sMumbai%2C+Maharashtra!5e0!3m2!1sen!2sin!4v1547151374329" frameborder="0"></iframe>
          </div>
          
      </div>
    </div>
    </div>
    <div class="container-fluid bottom-footer pt-2">
      <div class="row">
        <div class="col-12 text-center">
          <p>Copyrights © 2018 - All rights reserved</p>
        </div>
      </div>
    </div>

  </footer>


</body>
</html>