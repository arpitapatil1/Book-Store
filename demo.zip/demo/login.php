
<!DOCTYPE html>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>
    <style>
        .container {
            top:50%;
            left: 50%;
            transform: translate3d(-50%,-50%, 0);
            position: absolute;
            width: 50%;
            border: 3px solid black;
            border-radius: 35px;
         }
         a{
             text-decoration:none;
             text-align: end;
             
         }
         body{
             background-image: url(product-images/back3.jpg);
             background-repeat: no-repeat;
             background-size: 100% 100%;
             background-attachment: fixed;
           }
    </style>
</head>
<body>
    <div class="container m-auto">
        <h2 style="text-align: center; color: black;">Login</h2><br>
    <form >
        <div class="form-group row">
          <label for="staticEmail" class="col-sm-4 col-form-label" style="text-align: end; color: white;"><b>User name</b></label>
          <div class="col-sm-8">
            <input type="text" class="form-control"  placeholder="User name" style="width:60% ">
          </div>
        </div>
        <div class="form-group row mt-5">
          <label for="inputPassword" class="col-sm-4 col-form-label" style="text-align: end; color: white;"><b>Password</b></label>
          <div class="col-sm-8">
            <input type="password" class="form-control" id="inputPassword" placeholder="Password" style="width:60% ">
            <a href="#">Forgot Password?</a><br><br>
            <button class=" btn btn-primary" name="login" formaction="indexnew.php">Login</button>
            <button type="submit" formaction="signin.php" class="btn btn-primary">Signin</button>
            
          </div>
          
        </div>
      </form>
</body>